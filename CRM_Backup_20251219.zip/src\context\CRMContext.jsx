import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAutomation } from './AutomationContext';

const CRMContext = createContext();

export const useCRM = () => {
    const context = useContext(CRMContext);
    if (!context) {
        throw new Error('useCRM must be used within a CRMProvider');
    }
    return context;
};

const initialFields = [
    { id: 'phone', label: 'Telefono', type: 'tel', required: true },
    { id: 'pec', label: 'PEC', type: 'email', required: false },
    { id: 'address', label: 'Indirizzo', type: 'text', required: false },
    { id: 'city', label: 'Città', type: 'text', required: false },
    { id: 'referral', label: 'Consigliato da', type: 'text', required: false },
    { id: 'model', label: 'Modello Interessato', type: 'text', required: false },
    { id: 'budget', label: 'Budget', type: 'number', required: false },
    { id: 'contactTime', label: 'Orario di Contatto', type: 'time', required: false },
    { id: 'notes', label: 'Note', type: 'textarea', required: false },
];

const initialLeads = [
    {
        id: '1',
        firstName: 'Mario',
        lastName: 'Rossi',
        email: 'mario.rossi@example.com',
        status: 'new',
        createdAt: new Date().toISOString(),
        data: {
            phone: '+39 333 1234567',
            city: 'Milano',
            model: 'Fiat 500',
            budget: '300',
            contactTime: '18:00',
            notes: 'Interessato a noleggio 36 mesi'
        },
        documents: []
    },
    {
        id: '2',
        firstName: 'Luigi',
        lastName: 'Verdi',
        email: 'luigi.verdi@example.com',
        status: 'contacted',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        data: {
            phone: '+39 333 9876543',
            city: 'Roma',
            model: 'Jeep Renegade',
            budget: '500',
            contactTime: '10:00',
            notes: ''
        },
        documents: []
    }
];

export const CRMProvider = ({ children }) => {
    const [leads, setLeads] = useState(() => {
        const saved = localStorage.getItem('crm_leads');
        return saved ? JSON.parse(saved) : initialLeads;
    });

    const [fields, setFields] = useState(() => {
        const saved = localStorage.getItem('crm_fields');
        if (saved) {
            const parsed = JSON.parse(saved);
            const existingIds = new Set(parsed.map(f => f.id));
            const missingDefaults = initialFields.filter(f => !existingIds.has(f.id));
            return [...parsed, ...missingDefaults];
        }
        return initialFields;
    });

    const [emailSettings, setEmailSettings] = useState(() => {
        const saved = localStorage.getItem('crm_email_settings');
        return saved ? JSON.parse(saved) : {
            host: 'smtps.aruba.it',
            imapHost: 'imaps.aruba.it',
            port: '465',
            user: '',
            pass: '',
            fromName: ''
        };
    });

    useEffect(() => {
        localStorage.setItem('crm_leads', JSON.stringify(leads));
    }, [leads]);

    useEffect(() => {
        localStorage.setItem('crm_fields', JSON.stringify(fields));
    }, [fields]);

    useEffect(() => {
        localStorage.setItem('crm_email_settings', JSON.stringify(emailSettings));
    }, [emailSettings]);

    const addLead = (lead) => {
        const newLead = {
            ...lead,
            id: crypto.randomUUID(),
            createdAt: new Date().toISOString(),
            status: lead.status || 'new',
            timeline: [],
            contracts: [],
            practices: []
        };
        setLeads(prev => [newLead, ...prev]);
    };


    const { triggerEvent, checkTimeRules } = useAutomation();

    // Check time rules periodically
    useEffect(() => {
        const interval = setInterval(() => {
            checkTimeRules(leads);
        }, 1000 * 60 * 60); // Every hour

        // Initial check
        checkTimeRules(leads);

        return () => clearInterval(interval);
    }, [leads]); // Re-run if leads change (or better, make checkTimeRules robust)

    const updateLead = (id, updates) => {
        setLeads(prev => {
            const currentLead = prev.find(l => l.id === id);
            if (!currentLead) return prev;

            // Check if status changed - We need to do this check differently to avoid side effects in reducer
            // But doing it here is actually common for immediate reaction, however strictly it's a side effect.
            // Better pattern: calculate new leads, set them, AND trigger event.
            return prev.map(lead => lead.id === id ? { ...lead, ...updates } : lead);
        });

        // Trigger Event Side Effect
        // We need the OLD status and NEW status.
        // Since setLeads is async, we can't get the 'optimistic' lead easily without finding it first.
        // To be safe and correct:
        const currentLead = leads.find(l => l.id === id);
        if (currentLead && updates.status && updates.status !== currentLead.status) {
            triggerEvent('ON_LEAD_STATUS_CHANGE', {
                lead: { ...currentLead, ...updates },
                oldStatus: currentLead.status,
                newStatus: updates.status
            });
        }
    };

    const deleteLead = (id) => {
        setLeads(prev => prev.filter(lead => lead.id !== id));
    };

    const addTimelineEvent = (leadId, event) => {
        setLeads(prev => prev.map(lead => {
            if (lead.id !== leadId) return lead;
            return {
                ...lead,
                timeline: [{
                    id: crypto.randomUUID(),
                    date: new Date().toISOString(),
                    ...event
                }, ...(lead.timeline || [])]
            };
        }));
    };

    const deleteTimelineEvent = (leadId, eventId) => {
        setLeads(prev => prev.map(lead => {
            if (lead.id !== leadId) return lead;
            return {
                ...lead,
                timeline: (lead.timeline || []).filter(e => (e.id || e.date) !== eventId)
            };
        }));
    };

    const updateTimelineEvent = (leadId, eventId, updatedData) => {
        setLeads(prev => prev.map(lead => {
            if (lead.id !== leadId) return lead;
            return {
                ...lead,
                timeline: (lead.timeline || []).map(e =>
                    (e.id || e.date) === eventId ? { ...e, ...updatedData } : e
                )
            };
        }));
    };

    const addContract = (leadId, contract) => {
        const newContract = {
            id: crypto.randomUUID(),
            createdAt: new Date().toISOString(),
            status: 'active',
            ...contract
        };
        setLeads(prev => prev.map(lead => {
            if (lead.id !== leadId) return lead;
            return {
                ...lead,
                contracts: [...(lead.contracts || []), newContract]
            };
        }));
    };

    const deleteContract = (leadId, contractId) => {
        setLeads(prev => prev.map(lead => {
            if (lead.id !== leadId) return lead;
            return {
                ...lead,
                contracts: (lead.contracts || []).filter(c => c.id !== contractId)
            };
        }));
    };

    const addPractice = (leadId, practice) => {
        const newPractice = {
            id: crypto.randomUUID(),
            createdAt: new Date().toISOString(),
            status: 'open',
            ...practice
        };
        setLeads(prev => prev.map(lead => {
            if (lead.id !== leadId) return lead;
            return {
                ...lead,
                practices: [...(lead.practices || []), newPractice]
            };
        }));
    };

    const addField = (field) => {
        const newField = { ...field, id: field.label.toLowerCase().replace(/\s+/g, '_') };
        setFields(prev => [...prev, newField]);
    };

    const removeField = (id) => {
        setFields(prev => prev.filter(field => field.id !== id));
    };

    const updateEmailSettings = (settings) => {
        setEmailSettings(settings);
    };

    const bulkDeleteLeads = (ids) => {
        setLeads(prev => prev.filter(lead => !ids.includes(lead.id)));
    };

    const updateLeadsStatusBulk = (ids, newStatus) => {
        setLeads(prev => prev.map(lead =>
            ids.includes(lead.id) ? { ...lead, status: newStatus } : lead
        ));
    };

    return (
        <CRMContext.Provider value={{
            leads,
            fields,
            emailSettings,
            updateEmailSettings,
            addLead,
            updateLead,
            deleteLead,
            bulkDeleteLeads,
            updateLeadsStatusBulk,
            addTimelineEvent,
            deleteTimelineEvent,
            updateTimelineEvent,
            addContract,
            deleteContract,
            addPractice,
            addField,
            removeField
        }}>
            {children}
        </CRMContext.Provider>
    );
};
